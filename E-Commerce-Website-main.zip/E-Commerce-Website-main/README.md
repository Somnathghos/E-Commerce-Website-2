# E-Commerce Website

## [Watch it on youtube](https://youtu.be/kSoen4NJnY0)
### Responsive-E-Commerce-Website---AroNus

- Responsive Clothing Landing Page Using HTML CSS & JavaScript
- Contains animations when scrolling.
- Includes a dark and light mode.
- Smooth scrolling in each section.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Code with Aarzoo](https://www.youtube.com/channel/UCSm-oKFIIqTHnXnVQoS5TOQ)

## Source Code 👇

### [Click Here](https://www.patreon.com/posts/e-commerce-75346445?utm_medium=clipboard_copy&utm_source=copyLink&utm_campaign=postshare_creator&utm_content=join_link)

## Preview
![E-Commerce Website](https://user-images.githubusercontent.com/59678435/204972454-5112e223-98d6-4c43-9c3e-19a08b1b61e1.png)


